#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from kobuki_msgs.msg import BumperEvent

class Robot:
	
	def __init__(self):
		# Define an instance variable (self.pub, say) to hold the rospy.Publisher.
		# It should publish Twist messages on the '/mobile_base/commands/velocity' topic.
		self.pub = rospy.Publisher("/mobile_base/commands/velocity", Twist, queue_size=10)
		
		# Subscribe to the BumperEvent messages that the robot driver publishes
		# on the '/mobile_base/events/bumper' topic.
		# It should identify the method to be called when a message arrives: self.bumped
		rospy.Subscriber("/mobile_base/events/bumper", BumperEvent, self.bumped)

		# Set up a variable to hold the robot's state (self.state, perhaps?)
		# and a variable to keep track of the time of the last state change
		self.state = "forward"

	def bumped(self, msg):
		# If the BumperEvent message says that we just hit something,
		# and we are currently in the "go forward" state, change
		# to the "go backward" state.   Make a note of the time.
		self.state = "backward"
		self.time = rospy.get_time()

	def run(self):
		rate = rospy.Rate(10)
		twist = Twist()
		while not rospy.is_shutdown():
			if self.state == "forward":
				# Set twist.linear.x to a positive value <= 0.2
				twist.linear.x = .2
				twist.angular.z = 0
 				# Publish twist
				self.pub.publish(twist)
			elif self.state == "backward":
				# Set twist.linear.x to a negative value >= -0.2
				twist.linear.x = -.2
				# Publish twist	
				self.pub.publish(twist)				
				# If enough time has elapsed, change to the "turn" state
				if rospy.get_time() - self.time >= 2:
					self.state = "turn"
					self.time = rospy.get_time()
			elif self.state == "turn":
				# Set twist.angular.z to a nonzero value
				twist.linear.x = 0
				twist.angular.z = .5
				# Publish twist 	
				self.pub.publish(twist)
				# If enough time has elapsed, change to the "go forward" state
				if rospy.get_time() - self.time >= 2:
					self.state = "forward"
			rate.sleep()
	
rospy.init_node('prison_break')
robot = Robot()
robot.run()
